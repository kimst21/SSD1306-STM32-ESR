/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : OLED 디스플레이 제어 프로그램
  ******************************************************************************
  * @attention
  * - STM32와 SSD1306 OLED 디스플레이를 사용하여 다양한 텍스트와 숫자를 출력.
  * - 스크롤링 효과와 숫자 출력을 포함.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"        // STM32 초기화 관련 헤더
#include "i2c.h"         // I2C 초기화 및 제어 관련 헤더
#include "gpio.h"        // GPIO 설정 및 제어 관련 헤더

/* USER CODE BEGIN Includes */
#include "fonts.h"       // SSD1306 디스플레이용 글꼴
#include "ssd1306.h"     // SSD1306 디스플레이 제어 라이브러리
/* USER CODE END Includes */

/* USER CODE BEGIN 0 */
char snum[5];            // 숫자를 문자열로 변환하여 저장할 배열
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  HAL_Init();                      // HAL 라이브러리 초기화
  SystemClock_Config();            // 시스템 클럭 설정
  MX_GPIO_Init();                  // GPIO 초기화
  MX_I2C3_Init();                  // I2C 초기화 (SSD1306 통신용)
  SSD1306_Init();                  // SSD1306 OLED 디스플레이 초기화

  // 초기 화면 설정
  SSD1306_GotoXY(0, 0);
  SSD1306_Puts("TOOLBOX", &Font_11x18, 1);
  SSD1306_GotoXY(0, 30);
  SSD1306_Puts("All-In-One", &Font_11x18, 1);
  SSD1306_UpdateScreen();
  HAL_Delay(1000);                 // 1초 대기

  // 스크롤 효과
  SSD1306_ScrollRight(0, 7);       // 오른쪽 스크롤
  HAL_Delay(3000);                 // 3초 대기
  SSD1306_ScrollLeft(0, 7);        // 왼쪽 스크롤
  HAL_Delay(3000);                 // 3초 대기
  SSD1306_Stopscroll();            // 스크롤 정지
  SSD1306_Clear();                 // 화면 초기화
  SSD1306_GotoXY(35, 0);
  SSD1306_Puts("SCORE", &Font_11x18, 1);

  // 숫자 출력 반복
  while (1)
  {
    for (int x = 1; x <= 10000; x++) {
      itoa(x, snum, 16);           // 숫자를 16진수 문자열로 변환
      SSD1306_GotoXY(0, 30);
      SSD1306_Puts("             ", &Font_16x26, 1); // 이전 숫자 지우기
      SSD1306_UpdateScreen();

      // 숫자 위치 설정 (숫자의 자릿수에 따라 위치 조정)
      if (x < 10) {
        SSD1306_GotoXY(53, 30);    // 1자리 수
      } else if (x < 100) {
        SSD1306_GotoXY(45, 30);    // 2자리 수
      } else if (x < 1000) {
        SSD1306_GotoXY(37, 30);    // 3자리 수
      } else {
        SSD1306_GotoXY(30, 30);    // 4자리 수
      }

      SSD1306_Puts(snum, &Font_16x26, 1); // 숫자 출력
      SSD1306_UpdateScreen();
      HAL_Delay(300);              // 300ms 대기
    }
  }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
